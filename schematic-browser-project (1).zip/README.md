# Schematic Browser (Fabric, Minecraft 1.21.4)

Version-sensitive values live in gradle.properties. Source layout:
- schematicbrowser/nbt, model, format, print, source - version-independent core
- schematicbrowser/client - Fabric client entrypoint (keybind: B)

Not compiled/tested by the author's tooling; first build may need small fixes.
