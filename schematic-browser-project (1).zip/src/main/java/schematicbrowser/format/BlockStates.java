package schematicbrowser.format;

import java.util.*;

final class BlockStates {
    private BlockStates() {}

    /** {Name, Properties{...}} -> "name[a=b,c=d]" */
    @SuppressWarnings("unchecked")
    static String toString(Map<String, Object> entry) {
        String name = (String) entry.get("Name");
        Map<String, Object> props = (Map<String, Object>) entry.get("Properties");
        if (props == null || props.isEmpty()) return name;
        StringBuilder sb = new StringBuilder(name).append('[');
        boolean first = true;
        for (Map.Entry<String, Object> e : new TreeMap<>(props).entrySet()) {
            if (!first) sb.append(',');
            sb.append(e.getKey()).append('=').append(e.getValue());
            first = false;
        }
        return sb.append(']').toString();
    }
}
