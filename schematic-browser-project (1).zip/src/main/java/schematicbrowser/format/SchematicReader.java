package schematicbrowser.format;

import schematicbrowser.model.Schematic;
import java.io.IOException;

public interface SchematicReader {
    Schematic read(byte[] data) throws IOException;

    static SchematicReader forFileName(String name) throws IOException {
        String n = name.toLowerCase();
        if (n.endsWith(".litematic")) return new LitematicReader();
        if (n.endsWith(".schem")) return new SpongeReader();
        throw new IOException("Unsupported format: " + name + " (supported: .litematic, .schem)");
    }
}
