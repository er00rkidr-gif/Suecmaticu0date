package schematicbrowser.source;

import java.io.IOException;
import java.util.List;

/** Implement one of these per website. The browser screen only talks to this interface. */
public interface SchematicSource {
    String id();
    String displayName();
    List<SchematicEntry> search(String query) throws IOException, InterruptedException;
    byte[] download(SchematicEntry entry) throws IOException, InterruptedException;
}
