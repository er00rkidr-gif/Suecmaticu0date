package schematicbrowser.source;

/** One search result from a source. */
public record SchematicEntry(String id, String title, String author, String thumbnailUrl, String downloadUrl, String fileName) {}
