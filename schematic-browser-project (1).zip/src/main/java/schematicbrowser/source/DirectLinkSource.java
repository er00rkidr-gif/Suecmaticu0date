package schematicbrowser.source;

import java.io.IOException;
import java.util.List;

/** Works with any site that serves a direct .litematic/.schem link. The query is the URL itself. */
public final class DirectLinkSource implements SchematicSource {
    public String id() { return "direct"; }
    public String displayName() { return "Paste a direct link"; }

    public List<SchematicEntry> search(String url) {
        String name = url.substring(url.lastIndexOf('/') + 1).split("\\?")[0];
        return List.of(new SchematicEntry(url, name, "unknown", null, url, name));
    }
    public byte[] download(SchematicEntry e) throws IOException, InterruptedException { return Http.getBytes(e.downloadUrl()); }
}
