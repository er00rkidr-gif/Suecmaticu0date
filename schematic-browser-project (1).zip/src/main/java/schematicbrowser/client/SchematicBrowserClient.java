package schematicbrowser.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class SchematicBrowserClient implements ClientModInitializer {
    private static KeyBinding openBrowser;
    private static KeyBinding cancelPrint;

    @Override
    public void onInitializeClient() {
        openBrowser = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.schematicbrowser.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "category.schematicbrowser"));
        cancelPrint = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.schematicbrowser.cancel", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.schematicbrowser"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openBrowser.wasPressed()) {
                if (client.player != null) client.setScreen(new BrowserScreen());
            }
            while (cancelPrint.wasPressed()) {
                Printer.cancel();
                if (client.player != null) client.player.sendMessage(Text.literal("Print cancelled"), true);
            }
            Printer.tick(client);
        });
    }
}
