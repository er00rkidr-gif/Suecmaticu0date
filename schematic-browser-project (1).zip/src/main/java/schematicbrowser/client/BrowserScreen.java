package schematicbrowser.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import schematicbrowser.format.SchematicReader;
import schematicbrowser.model.Schematic;
import schematicbrowser.source.SchematicEntry;
import schematicbrowser.source.SchematicSource;

import java.util.List;
import java.util.concurrent.CompletableFuture;

public class BrowserScreen extends Screen {
    private static final int ROW = 22, MAX_ROWS = 8;

    private final List<SchematicSource> sources = Sources.all();
    private int sourceIndex = 0;
    private TextFieldWidget queryField;
    private volatile List<SchematicEntry> results = List.of();
    private volatile String status = "Pick a source, type a search (or paste a link), press Search";
    private volatile boolean busy = false;

    public BrowserScreen() { super(Text.literal("Schematic Browser")); }

    private String sourceLabel() { return "Source: " + sources.get(sourceIndex).displayName() + "  (click to change)"; }

    @Override
    protected void init() {
        int cx = width / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal(sourceLabel()), b -> {
            sourceIndex = (sourceIndex + 1) % sources.size();
            b.setMessage(Text.literal(sourceLabel()));
            results = List.of();
        }).dimensions(cx - 200, 30, 400, 20).build());

        queryField = new TextFieldWidget(textRenderer, cx - 200, 56, 290, 20, Text.literal("Search"));
        queryField.setMaxLength(500);
        addDrawableChild(queryField);
        setInitialFocus(queryField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Search"), b -> search())
                .dimensions(cx + 100, 56, 100, 20).build());
    }

    private void search() {
        if (busy) return;
        SchematicSource src = sources.get(sourceIndex);
        String q = queryField.getText().trim();
        busy = true;
        status = "Searching...";
        results = List.of();
        CompletableFuture.runAsync(() -> {
            try {
                List<SchematicEntry> r = src.search(q);
                results = r.size() > MAX_ROWS ? r.subList(0, MAX_ROWS) : r;
                status = r.isEmpty()
                        ? "No results (GitHub source: add repos to config/schematicbrowser.txt)"
                        : r.size() + " result(s) - click one to preview";
            } catch (Exception e) {
                status = "Error: " + e.getMessage();
            } finally {
                busy = false;
            }
        });
    }

    private void open(SchematicEntry entry) {
        if (busy) return;
        SchematicSource src = sources.get(sourceIndex);
        busy = true;
        status = "Downloading " + entry.title() + "...";
        CompletableFuture.runAsync(() -> {
            try {
                byte[] data = src.download(entry);
                Schematic s = SchematicReader.forFileName(entry.fileName()).read(data);
                MinecraftClient mc = MinecraftClient.getInstance();
                mc.execute(() -> mc.setScreen(new PreviewScreen(this, s, entry.title())));
                status = "";
            } catch (Throwable t) {
                status = "Error: " + t.getMessage();
            } finally {
                busy = false;
            }
        });
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, title, cx, 12, 0xFFFFFFFF);
        String st = status;
        ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(st, 400), cx - 200, 84,
                st.startsWith("Error") ? 0xFFFF5555 : 0xFFAAAAAA);
        int y = 100;
        for (SchematicEntry e : results) {
            boolean hover = mx >= cx - 200 && mx <= cx + 200 && my >= y && my < y + ROW - 2;
            ctx.fill(cx - 200, y, cx + 200, y + ROW - 2, hover ? 0xFF3A3A5A : 0xFF222233);
            ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(e.title() + " - " + e.author(), 388),
                    cx - 195, y + 6, 0xFFFFFFFF);
            y += ROW;
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int cx = width / 2, y = 100;
        for (SchematicEntry e : results) {
            if (mx >= cx - 200 && mx <= cx + 200 && my >= y && my < y + ROW - 2) {
                open(e);
                return true;
            }
            y += ROW;
        }
        return super.mouseClicked(mx, my, button);
    }
}
