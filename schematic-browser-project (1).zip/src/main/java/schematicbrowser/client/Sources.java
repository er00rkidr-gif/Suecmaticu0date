package schematicbrowser.client;

import net.fabricmc.loader.api.FabricLoader;
import schematicbrowser.source.DirectLinkSource;
import schematicbrowser.source.GitHubSource;
import schematicbrowser.source.SchematicSource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class Sources {
    private Sources() {}

    public static List<SchematicSource> all() {
        List<SchematicSource> list = new ArrayList<>();
        list.add(new DirectLinkSource());
        list.add(new GitHubSource(loadRepos()));
        return list;
    }

    /** config/schematicbrowser.txt: one "owner/repo" or "owner/repo/folder" per line. */
    private static List<String> loadRepos() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("schematicbrowser.txt");
        List<String> out = new ArrayList<>();
        try {
            if (!Files.exists(p)) {
                Files.writeString(p, "# One GitHub repo per line: owner/repo   or   owner/repo/folder\n"
                        + "# The folder must contain .litematic or .schem files.\n");
            }
            for (String line : Files.readAllLines(p)) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) out.add(line);
            }
        } catch (IOException ignored) {}
        return out;
    }
}
