package schematicbrowser.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import schematicbrowser.model.Schematic;
import schematicbrowser.print.PrintPlanner;

import java.util.List;

/** Top-down layer-by-layer blueprint view with a Print button. */
public class PreviewScreen extends Screen {
    private final Screen parent;
    private final Schematic s;
    private final String name;
    private final int[] paletteColors;
    private int layer = 0;
    private String info = "";

    public PreviewScreen(Screen parent, Schematic s, String name) {
        super(Text.literal("Blueprint"));
        this.parent = parent;
        this.s = s;
        this.name = name;
        this.paletteColors = new int[s.palette.size()];
        for (int i = 0; i < paletteColors.length; i++) paletteColors[i] = color(s.palette.get(i));
    }

    private static int color(String state) {
        int br = state.indexOf('[');
        String n = br < 0 ? state : state.substring(0, br);
        int h = n.hashCode() * 0x9E3779B1;
        int r = 80 + ((h >>> 16) & 0x7F), g = 80 + ((h >>> 8) & 0x7F), b = 80 + (h & 0x7F);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override
    protected void init() {
        int y = height - 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> client.setScreen(parent))
                .dimensions(10, y, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Layer -"), b -> layer = Math.max(0, layer - 1))
                .dimensions(80, y, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Layer +"), b -> layer = Math.min(s.height - 1, layer + 1))
                .dimensions(155, y, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Print next to me"), b -> print())
                .dimensions(width - 170, y, 160, 20).build());
    }

    private void print() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) return;
        BlockPos p = c.player.getBlockPos();
        List<String> cmds = PrintPlanner.plan(s, p.getX() + 2, p.getY(), p.getZ() + 2);
        Printer.start(cmds);
        c.setScreen(null);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(name, width - 20), 10, 8, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer,
                s.width + " x " + s.height + " x " + s.length + "   blocks: " + s.nonAirCount()
                        + "   layer " + (layer + 1) + "/" + s.height + "   (top-down view)", 10, 22, 0xFFAAAAAA);

        int left = 10, top = 40, availW = width - 20, availH = height - 80;
        int cell = Math.max(1, Math.min(availW / s.width, availH / s.length));
        ctx.fill(left, top, left + s.width * cell, top + s.length * cell, 0xFF111118);
        for (int z = 0; z < s.length; z++) {
            for (int x = 0; x < s.width; x++) {
                int id = s.blocks[s.index(x, layer, z)];
                if (s.isAir(s.palette.get(id))) continue;
                int px = left + x * cell, pz = top + z * cell;
                ctx.fill(px, pz, px + cell, pz + cell, paletteColors[id]);
            }
        }
    }
}
