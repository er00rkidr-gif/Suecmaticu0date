package schematicbrowser.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import java.util.ArrayDeque;
import java.util.List;

/** Sends queued /fill and /setblock commands a few per tick. Needs operator permission / cheats. */
public final class Printer {
    private static final ArrayDeque<String> QUEUE = new ArrayDeque<>();
    private static int total;
    public static int perTick = 5;

    private Printer() {}

    public static void start(List<String> cmds) {
        QUEUE.clear();
        QUEUE.addAll(cmds);
        total = cmds.size();
    }

    public static void cancel() { QUEUE.clear(); }

    public static void tick(MinecraftClient c) {
        if (QUEUE.isEmpty() || c.player == null || c.player.networkHandler == null) return;
        for (int i = 0; i < perTick && !QUEUE.isEmpty(); i++) {
            c.player.networkHandler.sendChatCommand(QUEUE.poll());
        }
        c.player.sendMessage(Text.literal("Printing: " + (total - QUEUE.size()) + "/" + total + "  (K to cancel)"), true);
    }
}
